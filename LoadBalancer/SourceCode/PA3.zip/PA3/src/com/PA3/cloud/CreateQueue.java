package com.PA3.cloud;

import java.io.*;
import java.util.HashMap;
import java.util.List;

import com.amazonaws.services.sqs.AmazonSQS;

/*import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.SendMessageRequest;*/
class Node {
	public HashMap<String, Integer> item;
	public Node next;

	public Node(HashMap<String, Integer> val) {
		item = val;
	}

	public void displayNode() {
		System.out.print("[" + item + "]");
	}

	public HashMap<String, Integer> getData() {
		return item;
	}
}

class LinkedList {
	private Node begin;
	private Node finish;

	public LinkedList() {
		begin = null;
		finish = null;
	}

	public boolean empty() {
		return begin == null;
	}

	public void insertEnd(HashMap<String, Integer> val) {

		Node newNode = new Node(val);
		if (empty())
			begin = newNode;
		else
			finish.next = newNode;
		finish = newNode;
	}

	public HashMap<String, Integer> deQueue() {

		HashMap<String, Integer> tmp = begin.item;
		if (begin.next == null)
			finish = null;
		begin = begin.next;
		return tmp;
	}

	public void displayList() {
		Node cur = begin;
		while (cur != null) {
			cur.displayNode();
			cur = cur.next;
		}
		System.out.println("");
	}

	
}

class Queue {
	private LinkedList listObj;

	public Queue() {
		listObj = new LinkedList();
	}

	public boolean isEmpty() {
		return listObj.empty();
	}

	public void insert(HashMap<String, Integer> k) {
		listObj.insertEnd(k);
	}

	public HashMap<String, Integer> deQueue() {
		return listObj.deQueue();
	}

	public void display() {
		System.out.print("Queue [FIFO]: ");
		listObj.displayList();
	}


}

class CreateQueue {
	public static long start;
	public static Queue result = new Queue();

	public static void main(String[] args) {

	}

}