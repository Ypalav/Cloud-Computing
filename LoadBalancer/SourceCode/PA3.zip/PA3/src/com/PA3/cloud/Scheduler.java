package com.PA3.cloud;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import com.SQS.sample.*;

public class Scheduler {
	public static float start;

	public static void main(String[] args) {

		try {
			
			String type = "";
			int n = 4;
			String fileName=args[0];
				Queue q = new Queue();
				BufferedReader br = new BufferedReader(new FileReader(fileName));
				
				 String ln="" , inf = "";
			        ln = br.readLine();
			        
			        while(ln != null){
			       			        inf = inf  + ln + "%";
			       			        ln = br.readLine();
			        }
			        inf = inf +"END";
				String[] d3 = inf.split("%");
				int j = 0;
				while (!d3[j].equals("END")) {
					HashMap<String, Integer> a = new HashMap<String, Integer>();
					a.put(d3[j], j);
					q.insert(a);
					j++;
				}
				//if (type.equals("lw")) {

					start = System.currentTimeMillis();
					System.out.println(start);
					PoolingService.init(n);
					Queue res = BckEndLWorkers.ProcessTask(q);
					res.display();

				//} else {
					/*q.processElement();
					start = System.currentTimeMillis();
					//BckEndRWorkers.main(d3);;
					//SimpleQueueServiceSample.main(d3);
					int size = SimpleQueueService.ResultQueue();
					if (size > 0)
						System.out.println("Result Queue received " + size);

				}
*/			//}

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
